import { useState } from "react"
import { Bot, Cpu, Zap, MoreVertical, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown"

const initialProviders = [
  {
    id: 1,
    name: "OpenAI",
    description: "GPT-4 and GPT-3.5 models for advanced reasoning.",
    status: "Active",
    tokens: "2.4M",
    logo: "bg-emerald-500",
  },
  {
    id: 2,
    name: "Anthropic Claude",
    description: "Claude 3 Opus and Sonnet models.",
    status: "Active",
    tokens: "1.1M",
    logo: "bg-orange-500",
  },
  {
    id: 3,
    name: "Google Gemini",
    description: "Gemini 1.5 Pro multimodal capabilities.",
    status: "Inactive",
    tokens: "0",
    logo: "bg-blue-500",
  }
]

export function AIProviders() {
  const [list, setList] = useState(initialProviders)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)
  
  const { addToast } = useToast()

  const handleOpenAdd = () => {
    setFormData({ name: '', description: '', status: 'Active' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleAddSubmit = (e) => {
    e.preventDefault()
    const newRecord = { ...formData, id: Date.now(), tokens: "0", logo: "bg-indigo-500" }
    setList([newRecord, ...list])
    setIsAddModalOpen(false)
    addToast(`Provider added successfully!`)
  }

  const handleEditSubmit = (e) => {
    e.preventDefault()
    setList(list.map(item => item.id === selectedItem.id ? { ...item, ...formData } : item))
    setIsEditModalOpen(false)
    addToast(`Provider updated successfully!`)
  }

  const handleDeleteSubmit = () => {
    setList(list.filter(item => item.id !== selectedItem.id))
    setIsDeleteModalOpen(false)
    addToast(`Provider deleted successfully!`, 'info')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">AI Providers</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Manage your AI model integrations and track token usage.
          </p>
        </div>
        <Button onClick={handleOpenAdd}>
          <Zap className="mr-2 h-4 w-4" /> Add Provider
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((provider) => (
          <div key={provider.id} className="flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
            <div className="flex items-center justify-between border-b border-slate-100 p-6 dark:border-slate-800/50">
              <div className="flex items-center space-x-4">
                <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${provider.logo}`}>
                  <Bot className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{provider.name}</h3>
                  <div className="mt-1 flex items-center space-x-2">
                    <div className={`h-2 w-2 rounded-full ${provider.status === 'Active' ? 'bg-green-500' : 'bg-slate-300 dark:bg-slate-700'}`} />
                    <span className="text-xs font-medium text-slate-500">{provider.status}</span>
                  </div>
                </div>
              </div>
              <Dropdown
                trigger={
                  <button className="text-slate-400 hover:text-slate-500 dark:hover:text-slate-300">
                    <MoreVertical className="h-5 w-5" />
                  </button>
                }
              >
                <DropdownItem icon={Edit} onClick={() => handleOpenEdit(provider)}>Edit Provider</DropdownItem>
                <DropdownItem icon={Trash2} onClick={() => handleOpenDelete(provider)}>Delete</DropdownItem>
              </Dropdown>
            </div>
            <div className="flex-1 p-6">
              <p className="text-sm text-slate-600 dark:text-slate-400">{provider.description}</p>
              
              <div className="mt-6 flex items-center justify-between rounded-lg bg-slate-50 p-4 dark:bg-slate-900/50">
                <div className="flex items-center text-sm font-medium text-slate-900 dark:text-white">
                  <Cpu className="mr-2 h-4 w-4 text-slate-400" />
                  Tokens Used
                </div>
                <span className="font-mono text-sm font-bold text-primary">{provider.tokens}</span>
              </div>
            </div>
            <div className="border-t border-slate-100 bg-slate-50 px-6 py-4 dark:border-slate-800/50 dark:bg-slate-900/50">
              <Button variant="outline" className="w-full" onClick={() => handleOpenEdit(provider)}>Configure</Button>
            </div>
          </div>
        ))}
      </div>

      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Add New Provider" : "Edit Provider"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Provider Name</label>
            <input type="text" required value={formData.name || ''} onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Meta Llama" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
            <textarea required value={formData.description || ''} onChange={(e) => setFormData(p => ({ ...p, description: e.target.value }))} placeholder="Describe models available..." className="w-full h-24 p-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white resize-none"></textarea>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
            <select value={formData.status || 'Active'} onChange={(e) => setFormData(p => ({ ...p, status: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Add Provider' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to remove the provider <strong>{selectedItem?.name}</strong>?
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete Provider
          </Button>
        </div>
      </Modal>
    </div>
  )
}

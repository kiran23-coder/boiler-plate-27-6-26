import { MasterDataLayout } from "../master/MasterData"

export function Departments() {
  const columns = [
    { key: "name", label: "Department Name", isPrimary: true },
    { key: "head", label: "Department Head" },
    { key: "employees", label: "Employees" },
  ]
  return <MasterDataLayout title="Departments" description="Manage company departments and structures." columns={columns} entity="department" />
}

export function Teams() {
  const columns = [
    { key: "name", label: "Team Name", isPrimary: true },
    { key: "department", label: "Department" },
    { key: "members", label: "Members" },
  ]
  return <MasterDataLayout title="Teams" description="Manage cross-functional teams." columns={columns} entity="team" />
}

export function UserActivityTimeline() {
  const columns = [
    { key: "user", label: "User", isPrimary: true },
    { key: "action", label: "Action" },
    { key: "module", label: "Module" },
    { key: "timestamp", label: "Timestamp" },
  ]
  const data = [
    { user: "Alice Freeman", action: "Created new Pipeline Deal", module: "CRM", timestamp: "2 mins ago" },
    { user: "Robert Johnson", action: "Updated Settings", module: "System", timestamp: "1 hour ago" },
  ]
  // Note: For now Activity Timeline stays static as requested for User Management Phase.
  return <MasterDataLayout title="Activity Timeline" description="View global user activities and audit trails." columns={columns} entity="" data={data} />
}

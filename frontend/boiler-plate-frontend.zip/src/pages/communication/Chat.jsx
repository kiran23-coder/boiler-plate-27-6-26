import { useState, useEffect, useRef } from "react"
import { Search, MoreVertical, Phone, Video, Info, Paperclip, Smile, Send, CheckCheck } from "lucide-react"
import { io } from "socket.io-client"
import { useAuth } from "@/contexts/AuthContext"

export function Chat() {
  const { user } = useAuth()
  const [contacts, setContacts] = useState([])
  const [activeContact, setActiveContact] = useState(null)
  const [messages, setMessages] = useState([])
  const [messageText, setMessageText] = useState("")
  const socketRef = useRef(null)
  const messagesEndRef = useRef(null)

  const token = localStorage.getItem('kiaan_token')

  // Fetch users (contacts)
  useEffect(() => {
    if (!token) return
    const fetchUsers = async () => {
      try {
        const res = await fetch('http://localhost:5000/api/v1/communication/chat/users', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        const data = await res.json()
        if (data.success) {
          // Map users to contacts format
          const formattedContacts = data.data.map((u, index) => {
            const colors = ["bg-purple-500", "bg-blue-500", "bg-orange-500", "bg-emerald-500"];
            return {
              id: u.id,
              name: `${u.firstName} ${u.lastName || ''}`.trim(),
              avatar: colors[index % colors.length],
              online: true 
            }
          })
          setContacts(formattedContacts)
          if (formattedContacts.length > 0) {
            setActiveContact(formattedContacts[0])
          }
        }
      } catch (err) {
        console.error("Failed to fetch users", err)
      }
    }
    fetchUsers()
  }, [token])

  // Connect to Socket
  useEffect(() => {
    if (!token) return

    socketRef.current = io("http://localhost:5000", {
      auth: { token }
    })

    socketRef.current.on('receive_message', (message) => {
      // Use function state to get the latest activeContact
      setActiveContact((currentActive) => {
        if (currentActive && (message.senderId === currentActive.id || message.receiverId === currentActive.id)) {
          setMessages(prev => {
            if (prev.find(m => m.id === message.id)) return prev;
            return [...prev, message]
          })
        }
        return currentActive;
      })
    })

    return () => {
      if (socketRef.current) socketRef.current.disconnect()
    }
  }, [token])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Fetch messages when contact is selected
  useEffect(() => {
    if (!activeContact || !token) return
    
    const fetchMessages = async () => {
      try {
        const res = await fetch(`http://localhost:5000/api/v1/communication/chat/messages/${activeContact.id}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        const data = await res.json()
        if (data.success) {
          setMessages(data.data)
        }
      } catch (err) {
        console.error("Failed to fetch messages", err)
      }
    }
    fetchMessages()
  }, [activeContact, token])

  const handleSendMessage = () => {
    if (!messageText.trim() || !activeContact || !socketRef.current) return
    
    socketRef.current.emit('send_message', {
      receiverId: activeContact.id,
      content: messageText
    })
    
    setMessageText("")
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex h-[calc(100vh-8rem)] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
      
      {/* Sidebar - Contacts */}
      <div className="w-80 shrink-0 border-r border-slate-200 flex flex-col dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">Messages</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search contacts..."
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {contacts.map((contact) => (
            <button
              key={contact.id}
              onClick={() => setActiveContact(contact)}
              className={`w-full flex items-start p-4 text-left transition-colors border-b border-slate-100 dark:border-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800/80 ${
                activeContact?.id === contact.id ? 'bg-white dark:bg-slate-800' : ''
              }`}
            >
              <div className="relative shrink-0 mr-3">
                <div className={`h-12 w-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${contact.avatar}`}>
                  {contact.name.charAt(0)}
                </div>
                {contact.online && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-green-500 dark:border-slate-900"></span>
                )}
              </div>
              <div className="flex-1 min-w-0 flex items-center h-full">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white truncate">{contact.name}</h3>
              </div>
            </button>
          ))}
          {contacts.length === 0 && (
            <div className="p-4 text-sm text-slate-500 text-center">No other users found in this tenant.</div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-white dark:bg-slate-950">
        {!activeContact ? (
          <div className="flex-1 flex items-center justify-center text-slate-400">
            Select a contact to start messaging
          </div>
        ) : (
          <>
            {/* Chat Header */}
            <div className="flex h-16 shrink-0 items-center justify-between border-b border-slate-200 px-6 dark:border-slate-800">
              <div className="flex items-center">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center text-white font-bold mr-3 ${activeContact.avatar}`}>
                  {activeContact.name.charAt(0)}
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900 dark:text-white">{activeContact.name}</h2>
                  <p className="text-xs text-green-500">{activeContact.online ? 'Online' : 'Offline'}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-slate-400">
                <button className="p-2 rounded-md hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300 transition-colors">
                  <Phone className="h-5 w-5" />
                </button>
                <button className="p-2 rounded-md hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300 transition-colors">
                  <Video className="h-5 w-5" />
                </button>
                <button className="p-2 rounded-md hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300 transition-colors">
                  <Info className="h-5 w-5" />
                </button>
                <button className="p-2 rounded-md hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-300 transition-colors">
                  <MoreVertical className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50 dark:bg-slate-900/20">
              {messages.length === 0 ? (
                <div className="flex h-full items-center justify-center text-sm text-slate-400">
                  No messages yet. Send a message to start the conversation!
                </div>
              ) : (
                messages.map((msg, idx) => {
                  const isMine = user && msg.senderId === user.id
                  return (
                    <div key={msg.id || idx} className={`flex items-end ${isMine ? 'justify-end' : ''}`}>
                      {!isMine && (
                        <div className={`h-8 w-8 rounded-full flex items-center justify-center text-white font-bold text-xs mr-2 shrink-0 ${activeContact.avatar}`}>
                          {activeContact.name.charAt(0)}
                        </div>
                      )}
                      <div className="max-w-[70%]">
                        <div className={`rounded-2xl px-4 py-2.5 text-sm shadow-sm ${
                          isMine 
                            ? 'rounded-br-none bg-primary text-white' 
                            : 'rounded-bl-none bg-slate-200 text-slate-900 dark:bg-slate-800 dark:text-white'
                        }`}>
                          {msg.content}
                        </div>
                        <div className={`mt-1 flex items-center space-x-1 ${isMine ? 'justify-end' : ''}`}>
                          <span className="text-xs text-slate-500">
                            {new Date(msg.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                          </span>
                          {isMine && <CheckCheck className="h-3 w-3 text-primary" />}
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 shrink-0">
              <div className="flex items-end space-x-2">
                <button className="shrink-0 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                  <Paperclip className="h-5 w-5" />
                </button>
                <div className="relative flex-1">
                  <textarea
                    rows={1}
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type your message..."
                    className="block w-full resize-none rounded-xl border border-slate-300 bg-white py-3 pl-4 pr-12 text-sm shadow-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <button className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                    <Smile className="h-5 w-5" />
                  </button>
                </div>
                <button 
                  onClick={handleSendMessage}
                  className="shrink-0 rounded-full bg-primary p-3 text-white shadow-sm hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
                >
                  <Send className="h-4 w-4 ml-0.5" />
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

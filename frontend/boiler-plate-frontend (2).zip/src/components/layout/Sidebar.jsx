import { useState } from "react"
import { Link, useLocation } from "react-router-dom"
import { 
  LayoutDashboard, Users, Settings, Building2, ShieldCheck, 
  CreditCard, Bell, FileBox, ActivitySquare, Bot, MessageSquare, 
  BarChart3, Database, ChevronDown, ChevronRight, Component, AlertTriangle
} from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { 
    name: 'Master Data', icon: Database,
    children: [
      { name: 'Countries', href: '/master/countries' },
      { name: 'States', href: '/master/states' },
      { name: 'Cities', href: '/master/cities' },
      { name: 'Categories', href: '/master/categories' },
      { name: 'Tags', href: '/master/tags' },
    ]
  },
  { name: 'Companies', href: '/tenants', icon: Building2 },
  { name: 'Roles & Permissions', href: '/roles', icon: ShieldCheck },
  { 
    name: 'Users', icon: Users,
    children: [
      { name: 'Departments', href: '/users/departments' },
      { name: 'Teams', href: '/users/teams' },
      { name: 'All Users', href: '/users' },
      { name: 'Activity Timeline', href: '/users/timeline' },
    ]
  },
  { 
    name: 'CRM', icon: Users,
    children: [
      { name: 'Leads', href: '/crm/leads' },
      { name: 'Pipeline Board', href: '/crm/pipeline' },
      { name: 'Tasks', href: '/crm/tasks' },
      { name: 'Follow Ups', href: '/crm/followups' },
    ]
  },
  { 
    name: 'Communication', icon: MessageSquare,
    children: [
      { name: 'Chat', href: '/communication/chat' },
      { name: 'Email Templates', href: '/communication/email' },
      { name: 'SMS Templates', href: '/communication/sms' },
      { name: 'WhatsApp Templates', href: '/communication/whatsapp' },
    ]
  },
  { 
    name: 'Billing', icon: CreditCard,
    children: [
      { name: 'Overview', href: '/billing' },
      { name: 'Plans', href: '/billing/plans' },
      { name: 'Usage Limits', href: '/billing/usage' },
      { name: 'Coupons', href: '/billing/coupons' },
      { name: 'Invoices', href: '/billing/invoices' },
      { name: 'Transactions', href: '/billing/transactions' },
    ]
  },
  { 
    name: 'Reports', icon: BarChart3,
    children: [
      { name: 'Analytics', href: '/reports/analytics' },
      { name: 'Scheduled Reports', href: '/reports/scheduled' },
      { name: 'Exports Center', href: '/reports/exports' },
    ]
  },
  { name: 'File Management', href: '/files', icon: FileBox },
  { 
    name: 'AI Module', icon: Bot,
    children: [
      { name: 'Providers', href: '/ai/providers' },
      { name: 'Prompt Templates', href: '/ai/templates' },
      { name: 'Token Usage', href: '/ai/tokens' },
      { name: 'Usage Logs', href: '/ai/logs' },
      { name: 'AI Settings', href: '/ai/settings' },
    ]
  },
  { 
    name: 'Audit Center', icon: ActivitySquare,
    children: [
      { name: 'Login Logs', href: '/audit/logins' },
      { name: 'API Logs', href: '/audit/api' },
      { name: 'Error Logs', href: '/audit/errors' },
    ]
  },
  { name: 'Notifications', href: '/notifications', icon: Bell },
  { 
    name: 'Components', icon: Component,
    children: [
      { name: 'UI Components', href: '/components/ui' },
      { name: 'DataTable', href: '/components/datatable' },
      { name: 'Form Builder', href: '/components/forms' },
    ]
  },
  { name: 'Error Pages', href: '/404', icon: AlertTriangle },
  { name: 'Settings', href: '/settings', icon: Settings },
]

const rolePermissions = {
  'Super Admin': ['Dashboard', 'Companies', 'Roles & Permissions', 'Users', 'Billing', 'CRM', 'AI Module', 'Communication', 'Reports', 'Master Data', 'Audit Center', 'Notifications', 'File Management', 'Components', 'Error Pages', 'Settings'],
  'Sales Agent': ['Dashboard', 'CRM', 'Communication', 'Notifications', 'Settings'],
  'Support Staff': ['Dashboard', 'CRM', 'Communication', 'Notifications', 'File Management', 'Settings']
}

function NavItem({ item, isActive, onLinkClick }) {
  const [open, setOpen] = useState(false)
  const hasChildren = item.children && item.children.length > 0

  if (hasChildren) {
    return (
      <div>
        <button
          onClick={() => setOpen(!open)}
          className="group flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 hover:text-primary dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
        >
          <div className="flex items-center">
            <item.icon className="mr-3 h-5 w-5 flex-shrink-0 text-slate-400 group-hover:text-primary" />
            {item.name}
          </div>
          {open ? (
            <ChevronDown className="h-4 w-4 text-slate-400 group-hover:text-primary" />
          ) : (
            <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-primary" />
          )}
        </button>
        {open && (
          <div className="mt-1 space-y-1 pl-10">
            {item.children.map((child) => (
              <Link
                key={child.name}
                to={child.href}
                onClick={onLinkClick}
                className="group flex items-center rounded-md px-3 py-2 text-sm font-medium text-slate-500 hover:text-primary dark:text-slate-400 dark:hover:text-white"
              >
                {child.name}
              </Link>
            ))}
          </div>
        )}
      </div>
    )
  }

  return (
    <Link
      to={item.href}
      onClick={onLinkClick}
      className={`
        group flex items-center rounded-md px-3 py-2 text-sm font-medium
        ${isActive 
          ? 'bg-slate-100 text-primary dark:bg-slate-800 dark:text-white' 
          : 'text-slate-700 hover:bg-slate-50 hover:text-primary dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
        }
      `}
    >
      <item.icon
        className={`mr-3 h-5 w-5 flex-shrink-0 ${isActive ? 'text-primary' : 'text-slate-400 group-hover:text-primary'}`}
        aria-hidden="true"
      />
      {item.name}
    </Link>
  )
}

export function Sidebar({ mobileMenuOpen, setMobileMenuOpen }) {
  const location = useLocation()
  const { user } = useAuth()
  
  const userRole = user?.role || 'Super Admin'
  const permittedMenus = rolePermissions[userRole] || rolePermissions['Super Admin']

  const filteredNavigation = navigation.filter(item => permittedMenus.includes(item.name))

  const handleLinkClick = () => {
    if (setMobileMenuOpen) {
      setMobileMenuOpen(false);
    }
  }

  const SidebarContent = (
    <div className="flex h-full flex-col bg-white dark:bg-slate-950">
      <div className="flex h-16 shrink-0 items-center justify-between border-b px-6 dark:border-slate-800">
        <span className="text-xl font-bold tracking-tight text-primary">Kiaan Core</span>
      </div>
      <div className="flex flex-1 flex-col overflow-y-auto">
        <nav className="flex-1 space-y-1 px-3 py-4">
          {filteredNavigation.map((item) => (
            <div key={item.name}>
              <NavItem 
                item={item} 
                isActive={location.pathname === item.href || (item.href !== '/' && location.pathname.startsWith(item.href))}
                onLinkClick={handleLinkClick}
              />
            </div>
          ))}
        </nav>
      </div>
    </div>
  )

  return (
    <>
      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div 
            className="fixed inset-0 bg-slate-900/80 transition-opacity backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <div className="relative flex w-full max-w-xs flex-1 transform transition-transform duration-300 ease-in-out">
            <div className="absolute right-0 top-0 -mr-12 pt-4">
              <button
                type="button"
                className="ml-1 flex h-10 w-10 items-center justify-center rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close sidebar</span>
                <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            {SidebarContent}
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-full w-64 flex-col border-r bg-white dark:bg-slate-950 dark:border-slate-800">
        {SidebarContent}
      </div>
    </>
  )
}


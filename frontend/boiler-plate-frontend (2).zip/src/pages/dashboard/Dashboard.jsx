import { useState, useEffect } from "react"
import { Users, Building2, CreditCard, ActivitySquare, Database, Cpu, Send, DollarSign } from "lucide-react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Link } from 'react-router-dom'
import { useToast } from "@/components/ui/ToastContext"

export function Dashboard() {
  const [data, setData] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const { addToast } = useToast()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('kiaan_token')
        const res = await fetch('http://localhost:5000/api/v1/reports/analytics', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        const result = await res.json()
        if (result.success) {
          setData(result.data)
        } else {
          addToast('Failed to load dashboard data', 'error')
        }
      } catch (error) {
        addToast('Error fetching dashboard data', 'error')
      } finally {
        setIsLoading(false)
      }
    }
    fetchData()
  }, [])

  const formatBytes = (bytes) => {
    if (!bytes || bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatNum = (num) => {
    if (!num) return '0'
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
    return num.toLocaleString()
  }

  if (isLoading) {
    return <div className="flex items-center justify-center h-full min-h-[500px] text-slate-500">Loading dashboard...</div>
  }

  const { stats, chartData } = data || { stats: {}, chartData: [] }

  const statCards = [
    { name: 'Total Users', value: formatNum(stats.totalUsers), change: '+0%', icon: Users, link: '/users' },
    { name: 'Active Users', value: formatNum(stats.activeUsers), change: '+0%', icon: ActivitySquare, link: '/users/activity' },
    { name: 'Total Companies', value: formatNum(stats.totalCompanies), change: '+0%', icon: Building2, link: '/tenants/companies' },
    { name: 'Branches', value: formatNum(stats.branches), change: '+0%', icon: Building2, link: '/tenants/branches' },
    { name: 'Revenue', value: `$${formatNum(stats.totalRevenue)}`, change: '+0%', icon: DollarSign, link: '/billing/overview' },
    { name: 'Active Plans', value: formatNum(stats.activePlans), change: '+0%', icon: CreditCard, link: '/billing/plans' },
    { name: 'Storage Usage', value: formatBytes(stats.storageUsageBytes), change: '+0%', icon: Database, link: '/files/library' },
    { name: 'API Requests', value: formatNum(stats.apiRequests), change: '+0%', icon: Send, link: '/audit/api-logs' },
    { name: 'AI Usage (Tokens)', value: formatNum(stats.aiUsageTokens), change: '+0%', icon: Cpu, link: '/ai/tokens' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Dashboard Overview</h1>
      </div>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {statCards.map((stat) => (
          <Link key={stat.name} to={stat.link} className="block group">
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-950 transition-all hover:border-primary/50 hover:shadow-md dark:hover:border-primary/50 h-full">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500 dark:text-slate-400 group-hover:text-primary transition-colors">{stat.name}</p>
                  <p className="mt-2 text-3xl font-bold text-slate-900 dark:text-white">{stat.value}</p>
                </div>
                <div className="rounded-full bg-primary/10 p-3 text-primary dark:bg-primary/20 group-hover:bg-primary group-hover:text-white transition-colors">
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className="font-medium text-green-600 dark:text-green-400">{stat.change}</span>
                <span className="ml-2 text-slate-500 dark:text-slate-400">from last month</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-950">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">Revenue Growth</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#aa3bff" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#aa3bff" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                <Tooltip />
                <Area type="monotone" dataKey="revenue" stroke="#aa3bff" fillOpacity={1} fill="url(#colorTotal)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-950">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-4">User Growth</h2>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                <Tooltip cursor={{fill: 'transparent'}} />
                <Bar dataKey="users" fill="#aa3bff" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  )
}


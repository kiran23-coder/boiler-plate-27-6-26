import { useState, useEffect } from "react"
import { Search, Plus, Shield, CheckCircle, XCircle, Settings2, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"

export function RolesList() {
  const [list, setList] = useState([])
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isPermissionsModalOpen, setIsPermissionsModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)
  const [permissionsMatrix, setPermissionsMatrix] = useState({})
  
  const { addToast } = useToast()

  const apiFetch = async (url, method = 'GET', body = null) => {
    const token = localStorage.getItem('kiaan_token');
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);
    const response = await fetch(`http://localhost:5000/api/v1${url}`, config);
    return await response.json();
  };

  const fetchRoles = async () => {
    const res = await apiFetch('/roles');
    if (res.success) {
      setList(res.data);
    }
  };

  useEffect(() => {
    fetchRoles();
  }, []);

  const handleOpenAdd = () => {
    setFormData({ name: '', description: '' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    if (item.isSystem) {
      addToast("System roles cannot be edited.", "error");
      return;
    }
    setSelectedItem(item)
    setFormData({ name: item.name, description: item.description })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    if (item.isSystem) {
      addToast("System roles cannot be deleted.", "error")
      return
    }
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleOpenPermissions = (item) => {
    setSelectedItem(item)
    setPermissionsMatrix(item.permissions || {})
    setIsPermissionsModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch('/roles', 'POST', formData);
    if (res.success) {
      setList([{ ...res.data, users: 0, permissions: {} }, ...list])
      setIsAddModalOpen(false)
      addToast(`Role added successfully!`)
    } else {
      addToast(res.error || 'Failed to add role', 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch(`/roles/${selectedItem.id}`, 'PUT', formData);
    if (res.success) {
      setList(list.map(item => item.id === selectedItem.id ? { ...item, ...res.data } : item))
      setIsEditModalOpen(false)
      addToast(`Role updated successfully!`)
    } else {
      addToast(res.error || 'Failed to update role', 'error')
    }
  }

  const handleDeleteSubmit = async () => {
    const res = await apiFetch(`/roles/${selectedItem.id}`, 'DELETE');
    if (res.success) {
      setList(list.filter(item => item.id !== selectedItem.id))
      setIsDeleteModalOpen(false)
      addToast(`Role deleted successfully!`, 'info')
    } else {
      addToast(res.error || 'Failed to delete role', 'error')
    }
  }

  const handlePermissionChange = (module, action, checked) => {
    setPermissionsMatrix(prev => ({
      ...prev,
      [module]: {
        ...(prev[module] || {}),
        [action]: checked
      }
    }));
  };

  const handleSavePermissions = async () => {
    const res = await apiFetch(`/roles/${selectedItem.id}/permissions`, 'PUT', { permissions: permissionsMatrix });
    if (res.success) {
      setList(list.map(item => item.id === selectedItem.id ? { ...item, permissions: permissionsMatrix } : item));
      setIsPermissionsModalOpen(false);
      addToast("Permissions updated successfully!");
    } else {
      addToast(res.error || 'Failed to update permissions', 'error');
    }
  };

  const modulesList = ['Dashboard', 'CRM', 'Billing', 'Users', 'Roles', 'Master Data', 'Reports', 'Settings'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center">
            <Shield className="mr-2 h-6 w-6 text-slate-400" /> Roles & Permissions
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Define access control roles and their associated permissions.
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">Permission Matrix</Button>
          <Button onClick={handleOpenAdd}>
            <Plus className="mr-2 h-4 w-4" /> Create Role
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {list.map((role) => (
          <div key={role.id} className="flex flex-col rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950 overflow-hidden">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800/50 flex justify-between items-start">
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="font-semibold text-lg text-slate-900 dark:text-white">{role.name}</h3>
                  {role.isSystem && (
                    <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10 dark:bg-blue-900/30 dark:text-blue-400 dark:ring-blue-400/20">
                      System
                    </span>
                  )}
                </div>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 h-10">{role.description}</p>
              </div>
              {!role.isSystem ? (
                <button onClick={() => handleOpenDelete(role)} className="p-1 rounded-md text-slate-500 dark:text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-900/20 transition-colors">
                  <Trash2 className="h-4 w-4" />
                </button>
              ) : (
                <div className="w-6"></div> /* spacer for alignment */
              )}
            </div>
            
            <div className="p-5 bg-slate-50/50 dark:bg-slate-900/20 flex-1 flex flex-col justify-between space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500 dark:text-slate-400">Assigned Users</span>
                <span className="font-medium text-slate-900 dark:text-white px-2 py-1 bg-slate-200 dark:bg-slate-800 rounded-md">
                  {role.users || 0}
                </span>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Read Access Configured
                </div>
                <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Write Access Configured
                </div>
                <div className="flex items-center text-sm text-slate-600 dark:text-slate-300">
                  {role.permissions && Object.values(role.permissions).some(m => m.delete) ? (
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="mr-2 h-4 w-4 text-red-400" />
                  )}
                  Delete Access
                </div>
              </div>
            </div>
            
            <div className="p-4 border-t border-slate-100 dark:border-slate-800/50 flex space-x-3">
              <Button variant="outline" className="flex-1 text-xs" onClick={() => handleOpenPermissions(role)}>
                <Settings2 className="mr-2 h-3 w-3" /> Permissions
              </Button>
              {!role.isSystem && (
                <Button variant="outline" className="flex-1 text-xs" onClick={() => handleOpenEdit(role)}>
                  <Edit className="mr-2 h-3 w-3" /> Edit Role
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>

      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Create New Role" : "Edit Role"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Role Name</label>
            <input type="text" required value={formData.name || ''} onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
            <textarea required value={formData.description || ''} onChange={(e) => setFormData(p => ({ ...p, description: e.target.value }))} className="w-full h-24 p-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white resize-none"></textarea>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Create Role' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete the role <strong>{selectedItem?.name}</strong>?
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete Role
          </Button>
        </div>
      </Modal>

      {/* Permissions Matrix Modal */}
      <Modal isOpen={isPermissionsModalOpen} onClose={() => setIsPermissionsModalOpen(false)} title={`Edit Permissions: ${selectedItem?.name}`}>
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
            Select the modules and access levels this role should have.
          </p>
          
          <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  <th className="px-4 py-3 font-medium text-slate-900 dark:text-slate-200">Module</th>
                  <th className="px-4 py-3 font-medium text-center text-slate-900 dark:text-slate-200">Read</th>
                  <th className="px-4 py-3 font-medium text-center text-slate-900 dark:text-slate-200">Write</th>
                  <th className="px-4 py-3 font-medium text-center text-slate-900 dark:text-slate-200">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {modulesList.map((moduleName) => {
                  const modPerms = permissionsMatrix[moduleName] || { read: false, write: false, delete: false };
                  return (
                    <tr key={moduleName} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="px-4 py-3 font-medium text-slate-700 dark:text-slate-300">{moduleName}</td>
                      <td className="px-4 py-3 text-center">
                        <input 
                          type="checkbox" 
                          checked={!!modPerms.read} 
                          onChange={(e) => handlePermissionChange(moduleName, 'read', e.target.checked)}
                          className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary dark:border-slate-700 dark:bg-slate-900" 
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <input 
                          type="checkbox" 
                          checked={!!modPerms.write} 
                          onChange={(e) => handlePermissionChange(moduleName, 'write', e.target.checked)}
                          className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary dark:border-slate-700 dark:bg-slate-900" 
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <input 
                          type="checkbox" 
                          checked={!!modPerms.delete} 
                          onChange={(e) => handlePermissionChange(moduleName, 'delete', e.target.checked)}
                          className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary dark:border-slate-700 dark:bg-slate-900" 
                        />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end items-center border-t border-slate-100 dark:border-slate-800 pt-4">
          <div className="flex space-x-3">
            <Button variant="outline" type="button" onClick={() => setIsPermissionsModalOpen(false)}>Cancel</Button>
            <Button type="button" onClick={handleSavePermissions}>Save Permissions</Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

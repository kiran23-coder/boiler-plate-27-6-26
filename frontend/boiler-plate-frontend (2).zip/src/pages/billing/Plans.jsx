import { useState, useEffect } from "react"
import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { useToast } from "@/components/ui/ToastContext"

export function Plans() {
  const [plans, setPlans] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const { addToast } = useToast()

  const fetchPlans = async () => {
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch('http://localhost:5000/api/v1/billing/plans', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      const data = await res.json()
      if (data.success) {
        setPlans(data.data)
      }
    } catch (error) {
      console.error("Failed to fetch plans:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchPlans()
  }, [])

  const handleSelectPlan = (plan) => {
    addToast(`Proceeding with ${plan.name} plan...`, "success")
    // Logic to initiate subscription update
  }

  if (isLoading) {
    return <div className="p-8 text-center text-slate-500">Loading plans...</div>
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-4xl">
          Pricing Plans
        </h1>
        <p className="mt-4 text-lg text-slate-500 dark:text-slate-400">
          Choose the right plan for your business. All plans include a 14-day free trial.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3 lg:gap-8 max-w-7xl mx-auto pt-8">
        {plans.length === 0 ? (
          <div className="col-span-full text-center text-slate-500 p-12 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
            No pricing plans configured in the database yet.
          </div>
        ) : (
          plans.map((plan) => (
            <div
              key={plan.id}
              className={`flex flex-col justify-between rounded-2xl p-8 shadow-sm ring-1 ${
                plan.highlighted
                  ? "bg-slate-900 ring-slate-900 dark:bg-slate-800 dark:ring-slate-800 text-white shadow-xl scale-105 z-10"
                  : "bg-white ring-slate-200 dark:bg-slate-950 dark:ring-slate-800"
              }`}
            >
              <div>
                <h3
                  className={`text-lg font-semibold leading-8 ${
                    plan.highlighted ? "text-white" : "text-slate-900 dark:text-white"
                  }`}
                >
                  {plan.name}
                </h3>
                <p
                  className={`mt-4 text-sm leading-6 ${
                    plan.highlighted ? "text-slate-300" : "text-slate-500 dark:text-slate-400"
                  }`}
                >
                  {plan.description}
                </p>
                <div className="mt-6 flex items-baseline gap-x-1">
                  <span
                    className={`text-4xl font-bold tracking-tight ${
                      plan.highlighted ? "text-white" : "text-slate-900 dark:text-white"
                    }`}
                  >
                    ${plan.price}
                  </span>
                  <span
                    className={`text-sm font-semibold leading-6 ${
                      plan.highlighted ? "text-slate-300" : "text-slate-500 dark:text-slate-400"
                    }`}
                  >
                    {plan.billingCycle}
                  </span>
                </div>
                
                {/* Features rendering */}
                <ul
                  className={`mt-8 space-y-3 text-sm leading-6 ${
                    plan.highlighted ? "text-slate-300" : "text-slate-600 dark:text-slate-400"
                  }`}
                >
                  {plan.features && typeof plan.features === 'object' && Array.isArray(plan.features) ? plan.features.map((feature, idx) => (
                    <li key={idx} className="flex gap-x-3">
                      {feature.included ? (
                        <Check
                          className={`h-6 w-5 flex-none ${
                            plan.highlighted ? "text-white" : "text-primary"
                          }`}
                          aria-hidden="true"
                        />
                      ) : (
                        <X
                          className={`h-6 w-5 flex-none ${
                            plan.highlighted ? "text-slate-500" : "text-slate-300 dark:text-slate-600"
                          }`}
                          aria-hidden="true"
                        />
                      )}
                      <span className={!feature.included ? "line-through opacity-70" : ""}>
                        {feature.name}
                      </span>
                    </li>
                  )) : null}
                </ul>
              </div>
              <div className="mt-8">
                <Button
                  onClick={() => handleSelectPlan(plan)}
                  variant={plan.highlighted ? "secondary" : "outline"}
                  className={`w-full ${
                    plan.highlighted
                      ? "bg-white text-slate-900 hover:bg-slate-100 dark:bg-primary dark:text-white dark:hover:bg-primary/90"
                      : ""
                  }`}
                >
                  {plan.cta || 'Select Plan'}
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

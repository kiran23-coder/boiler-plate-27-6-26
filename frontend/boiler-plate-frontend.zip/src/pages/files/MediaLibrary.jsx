import { useState } from "react"
import { FileBox, UploadCloud, Search, Folder, Image as ImageIcon, FileText, MoreVertical, LayoutGrid, List } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { useSystem } from "@/contexts/SystemContext"

export function MediaLibrary() {
  const { files, uploadFile } = useSystem()
  const { addToast } = useToast()
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false)
  const [fileName, setFileName] = useState("")
  return (
    <div className="space-y-6 flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center">
            <FileBox className="mr-2 h-6 w-6 text-slate-400" /> Media & Files
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Manage your tenant's uploaded files and assets.
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Folder className="mr-2 h-4 w-4" /> New Folder
          </Button>
          <Button onClick={() => { setFileName(""); setIsUploadModalOpen(true); }}>
            <UploadCloud className="mr-2 h-4 w-4" /> Upload
          </Button>
        </div>
      </div>

      <div className="flex-1 flex flex-col min-h-0 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0 shrink-0">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search files and folders..."
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
          <div className="flex items-center space-x-2 border rounded-md border-slate-200 p-1 dark:border-slate-700">
            <button className="p-1.5 rounded bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button className="p-1.5 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-300">
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
            {files.map((file) => (
              <div key={file.id} className="group relative flex flex-col items-center justify-center rounded-xl border border-slate-200 bg-white p-4 text-center hover:border-primary/50 hover:shadow-md dark:border-slate-800 dark:bg-slate-950 dark:hover:border-primary/50 transition-all cursor-pointer">
                <button className="absolute right-2 top-2 rounded p-1 text-slate-400 opacity-0 hover:bg-slate-100 hover:text-slate-600 group-hover:opacity-100 dark:hover:bg-slate-800 dark:hover:text-slate-300">
                  <MoreVertical className="h-4 w-4" />
                </button>
                {file.type === "pdf" && <FileText className={`h-12 w-12 mb-3 ${file.color}`} />}
                {file.type === "image" && <ImageIcon className={`h-12 w-12 mb-3 ${file.color}`} />}
                {file.type === "folder" && <Folder className={`h-12 w-12 mb-3 ${file.color}`} />}
                {!["pdf", "image", "folder"].includes(file.type) && <FileText className={`h-12 w-12 mb-3 ${file.color}`} />}
                <h3 className="w-full truncate text-sm font-medium text-slate-900 dark:text-white" title={file.name}>
                  {file.name}
                </h3>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  {file.size !== '--' ? file.size : file.date}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Modal isOpen={isUploadModalOpen} onClose={() => setIsUploadModalOpen(false)} title="Upload Mock File">
        <form onSubmit={(e) => {
          e.preventDefault();
          let type = "pdf";
          let color = "text-red-500";
          if (fileName.endsWith(".png") || fileName.endsWith(".jpg") || fileName.endsWith(".svg")) {
            type = "image";
            color = "text-blue-500";
          }
          uploadFile({
            name: fileName,
            type: type,
            size: "1.2 MB",
            date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
            color: color
          });
          setIsUploadModalOpen(false);
          addToast("File uploaded successfully!");
        }} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">File Name</label>
            <input type="text" required value={fileName} onChange={(e) => setFileName(e.target.value)} placeholder="e.g. invoice_001.pdf" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => setIsUploadModalOpen(false)}>Cancel</Button>
            <Button type="submit"><UploadCloud className="mr-2 h-4 w-4" /> Mock Upload</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

import React, { createContext, useContext, useState, useEffect } from 'react';

const CRMContext = createContext();

export const useCRM = () => {
  const context = useContext(CRMContext);
  if (!context) {
    throw new Error('useCRM must be used within a CRMProvider');
  }
  return context;
};

export const CRMProvider = ({ children }) => {
  const [leads, setLeads] = useState([]);
  const pipelineStages = [
    { id: "NEW", title: "New Leads", color: "border-blue-500", cards: leads.filter(l => l.status === "NEW").map(l => ({ id: l.id, title: l.name, company: l.companyName || l.company, amount: l.dealAmount ? `$${l.dealAmount}` : '-', date: l.createdAt ? new Date(l.createdAt).toLocaleDateString() : 'Today', tasks: 0, files: 0 })) },
    { id: "CONTACTED", title: "Contacted", color: "border-yellow-500", cards: leads.filter(l => l.status === "CONTACTED").map(l => ({ id: l.id, title: l.name, company: l.companyName || l.company, amount: l.dealAmount ? `$${l.dealAmount}` : '-', date: l.createdAt ? new Date(l.createdAt).toLocaleDateString() : 'Today', tasks: 0, files: 0 })) },
    { id: "QUALIFIED", title: "Qualified", color: "border-purple-500", cards: leads.filter(l => l.status === "QUALIFIED").map(l => ({ id: l.id, title: l.name, company: l.companyName || l.company, amount: l.dealAmount ? `$${l.dealAmount}` : '-', date: l.createdAt ? new Date(l.createdAt).toLocaleDateString() : 'Today', tasks: 0, files: 0 })) },
    { id: "WON", title: "Closed Won", color: "border-green-500", cards: leads.filter(l => l.status === "WON").map(l => ({ id: l.id, title: l.name, company: l.companyName || l.company, amount: l.dealAmount ? `$${l.dealAmount}` : '-', date: l.createdAt ? new Date(l.createdAt).toLocaleDateString() : 'Today', tasks: 0, files: 0 })) },
  ];

  // Provide a dummy setter if some component tries to call setPipelineStages
  const setPipelineStages = () => {};

  const [followUps, setFollowUps] = useState([]);
  const [tasks, setTasks] = useState([]);

  // Helper for requests
  const apiFetch = async (url, method = 'GET', body = null) => {
    const token = localStorage.getItem('kiaan_token');
    if (!token) return { success: false };

    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };

    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);

    const response = await fetch(`http://localhost:5000/api/v1${url}`, config);
    return await response.json();
  };

  const fetchCRMData = async () => {
    // Fetch Leads
    const leadsRes = await apiFetch('/crm/leads');
    if (leadsRes.success) setLeads(leadsRes.data);

    // Fetch Tasks
    const tasksRes = await apiFetch('/crm/tasks');
    if (tasksRes.success) setTasks(tasksRes.data);

    // Fetch Follow Ups
    const followUpsRes = await apiFetch('/crm/followups');
    if (followUpsRes.success) setFollowUps(followUpsRes.data);
  };

  useEffect(() => {
    fetchCRMData();
  }, []);

  // LEADS
  const addLead = async (lead) => {
    const res = await apiFetch('/crm/leads', 'POST', lead);
    if (res.success) {
      setLeads([res.data, ...leads]);
    }
    return res;
  };

  const updateLead = async (updatedLead) => {
    const res = await apiFetch(`/crm/leads/${updatedLead.id}`, 'PUT', updatedLead);
    if (res.success) {
      setLeads(leads.map(l => l.id === updatedLead.id ? res.data : l));
    }
    return res;
  };

  const deleteLead = async (leadId) => {
    const res = await apiFetch(`/crm/leads/${leadId}`, 'DELETE');
    if (res.success) {
      setLeads(leads.filter(l => l.id !== leadId));
    }
    return res;
  };

  const convertToDeal = async (leadId, amount) => {
    const lead = leads.find(l => l.id === leadId);
    if (!lead) return;

    // Update lead status to Qualified in Backend and set dealAmount
    const res = await apiFetch(`/crm/leads/${leadId}`, 'PUT', { ...lead, status: 'QUALIFIED', dealAmount: amount });
    if (res.success) {
      updateLead(res.data);
    }
  };

  const addDealToPipeline = async (deal, stageId = "NEW") => {
    // Treat deal as a new lead
    const newLead = {
      name: deal.title,
      companyName: deal.company,
      dealAmount: deal.amount ? deal.amount.replace(/[^0-9.]/g, '') : null,
      status: stageId,
      source: 'Website'
    };
    await addLead(newLead);
  };

  // TASKS
  const addTask = async (task) => {
    const res = await apiFetch('/crm/tasks', 'POST', task);
    if (res.success) {
      setTasks([res.data, ...tasks]);
    }
  };

  const updateTask = async (updatedTask) => {
    const res = await apiFetch(`/crm/tasks/${updatedTask.id}`, 'PUT', updatedTask);
    if (res.success) {
      setTasks(tasks.map(t => t.id === updatedTask.id ? res.data : t));
    }
  };

  const deleteTask = async (taskId) => {
    const res = await apiFetch(`/crm/tasks/${taskId}`, 'DELETE');
    if (res.success) {
      setTasks(tasks.filter(t => t.id !== taskId));
    }
  };

  // FOLLOW UPS
  const addFollowUp = async (followUp) => {
    const res = await apiFetch('/crm/followups', 'POST', followUp);
    if (res.success) {
      setFollowUps([res.data, ...followUps]);
    }
    return res;
  };

  const updateFollowUp = async (updatedFollowUp) => {
    const res = await apiFetch(`/crm/followups/${updatedFollowUp.id}`, 'PUT', updatedFollowUp);
    if (res.success) {
      setFollowUps(followUps.map(f => f.id === updatedFollowUp.id ? res.data : f));
    }
    return res;
  };

  const deleteFollowUp = async (id) => {
    const res = await apiFetch(`/crm/followups/${id}`, 'DELETE');
    if (res.success) {
      setFollowUps(followUps.filter(f => f.id !== id));
    }
    return res;
  };

  return (
    <CRMContext.Provider value={{ 
      leads, addLead, updateLead, deleteLead, convertToDeal,
      pipelineStages, setPipelineStages, addDealToPipeline,
      followUps, setFollowUps, addFollowUp, updateFollowUp, deleteFollowUp,
      tasks, setTasks, addTask, updateTask, deleteTask
    }}>
      {children}
    </CRMContext.Provider>
  );
};

import { useState, useMemo, useEffect } from "react"
import { Search, Plus, MoreHorizontal, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"

// Generic Master Data component that handles full CRUD local state operations
export function MasterDataLayout({ title, description, columns, entity, data = null }) {
  const [list, setList] = useState(data || [])
  const [searchTerm, setSearchTerm] = useState("")
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)

  const { addToast } = useToast()

  // API Helper
  const apiFetch = async (url, method = 'GET', body = null) => {
    try {
      const token = localStorage.getItem('kiaan_token');
      if (!token) return { success: false, error: 'No token found' };

      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };

      const config = { method, headers };
      if (body) config.body = JSON.stringify(body);

      const response = await fetch(`http://localhost:5000/api/v1${url}`, config);
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { success: false, error: `Server returned non-JSON response (${response.status})` };
      }
      return await response.json();
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const fetchList = async () => {
    if (!entity || data) return;
    const res = await apiFetch(`/master/${entity}`);
    if (res.success) {
      setList(res.data);
    }
  };

  useEffect(() => {
    fetchList();
  }, [entity]);

  // Helper to get singular form
  const singularTitle = useMemo(() => {
    if (title.endsWith('ies')) return title.slice(0, -3) + 'y'
    if (title.endsWith('ses') || title.endsWith('xes')) return title.slice(0, -2)
    if (title.endsWith('s') && !title.endsWith('ss')) return title.slice(0, -1)
    return title
  }, [title])

  // Filter data based on search
  const filteredList = useMemo(() => {
    if (!searchTerm) return list
    return list.filter(item => 
      Object.values(item).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  }, [list, searchTerm])

  const handleOpenAdd = () => {
    const initialForm = {}
    columns.forEach(col => {
      if (col.key !== 'id') {
        initialForm[col.key] = ''
      }
    })
    setFormData(initialForm)
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch(`/master/${entity}`, 'POST', formData);
    if (res.success) {
      setList([res.data, ...list])
      setIsAddModalOpen(false)
      addToast(`${singularTitle} added successfully!`)
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch(`/master/${entity}/${selectedItem.id}`, 'PUT', formData);
    if (res.success) {
      setList(list.map(item => item.id === selectedItem.id ? res.data : item))
      setIsEditModalOpen(false)
      addToast(`${singularTitle} updated successfully!`)
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleDeleteSubmit = async () => {
    const res = await apiFetch(`/master/${entity}/${selectedItem.id}`, 'DELETE');
    if (res.success) {
      setList(list.filter(item => item.id !== selectedItem.id))
      setIsDeleteModalOpen(false)
      addToast(`${singularTitle} deleted successfully!`, 'info')
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  // Helper to render form inputs based on columns
  const renderFormInputs = () => {
    return columns.map(col => {
      if (col.key === 'id' || col.hideInForm) return null
      
      if (col.type === 'select' && col.options) {
        return (
          <div key={col.key} className="mb-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
              {col.label}
            </label>
            <select
              required
              value={formData[col.key] || col.options[0]}
              onChange={(e) => handleInputChange(col.key, e.target.value)}
              className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            >
              {col.options.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>
        )
      }

      return (
        <div key={col.key} className="mb-4">
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            {col.label}
          </label>
          <input
            type="text"
            required
            value={formData[col.key] !== undefined ? formData[col.key] : ''}
            onChange={(e) => handleInputChange(col.key, e.target.value)}
            className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
          />
        </div>
      )
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">{title}</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {description}
          </p>
        </div>
        {entity && (
          <Button onClick={handleOpenAdd}>
            <Plus className="mr-2 h-4 w-4" /> Add {singularTitle}
          </Button>
        )}
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={`Search ${title.toLowerCase()}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
          <div className="text-sm text-slate-500 dark:text-slate-400">
            Showing {filteredList.length} items
          </div>
        </div>

        {filteredList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-slate-100 p-3 dark:bg-slate-800 mb-4">
              <Search className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No items found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {entity ? `Get started by creating a new ${singularTitle.toLowerCase()}.` : 'No data available for this view.'}
            </p>
            {entity && (
              <Button className="mt-4" onClick={handleOpenAdd}>
                <Plus className="mr-2 h-4 w-4" /> Add {singularTitle}
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full whitespace-nowrap text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  {columns.map((col) => (
                    <th key={col.key} className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">
                      {col.label}
                    </th>
                  ))}
                  {entity && <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
                {filteredList.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    {columns.map((col) => (
                      <td key={`${i}-${col.key}`} className={`px-6 py-4 text-slate-500 dark:text-slate-400 ${col.isPrimary ? 'font-medium text-slate-900 dark:text-white' : ''}`}>
                        {col.render ? col.render(row[col.key], row) : row[col.key]}
                      </td>
                    ))}
                    {entity && (
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end space-x-2">
                          <button 
                            onClick={() => handleOpenEdit(row)}
                            className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-slate-800 dark:hover:text-primary transition-colors"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button 
                            onClick={() => handleOpenDelete(row)}
                            className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-red-500 dark:hover:bg-slate-800 dark:hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title={`Add New ${singularTitle}`}>
        <form onSubmit={handleAddSubmit}>
          {renderFormInputs()}
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => setIsAddModalOpen(false)}>Cancel</Button>
            <Button type="submit">Create</Button>
          </div>
        </form>
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} title={`Edit ${singularTitle}`}>
        <form onSubmit={handleEditSubmit}>
          {renderFormInputs()}
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => setIsEditModalOpen(false)}>Cancel</Button>
            <Button type="submit">Save Changes</Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete this item? This action cannot be undone.
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete
          </Button>
        </div>
      </Modal>
    </div>
  )
}

// Example Wrapper for Countries
export function Countries() {
  const columns = [
    { key: "code", label: "Code", isPrimary: true },
    { key: "name", label: "Country Name" },
    { key: "currency", label: "Currency" },
    { 
      key: "status", 
      label: "Status",
      render: (val) => (
        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
          val === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
          'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400'
        }`}>
          {val}
        </span>
      )
    }
  ]

  return <MasterDataLayout title="Countries" description="Manage countries for localization and addresses." columns={columns} entity="country" />
}

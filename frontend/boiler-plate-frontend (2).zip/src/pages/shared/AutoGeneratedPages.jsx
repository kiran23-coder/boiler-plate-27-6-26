import { useState, useEffect } from "react"
import { MasterDataLayout } from "../master/MasterData"

export function BillingOverview() {
  const [data, setData] = useState([])
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('kiaan_token')
        const res = await fetch('http://localhost:5000/api/v1/billing/overview', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        const json = await res.json()
        if (json.success) {
          setData([
            { metric: "Current MRR", value: `$${json.data.mrr}` },
            { metric: "Active Subscriptions", value: `${json.data.activeSubscriptions}` }
          ])
        }
      } catch (error) {
        console.error("Failed to fetch billing overview", error)
      }
    }
    fetchData()
  }, [])

  const columns = [{ key: "metric", label: "Metric", isPrimary: true }, { key: "value", label: "Value" }]
  return <MasterDataLayout title="Billing Overview" description="Summary of your billing metrics." columns={columns} data={data} />
}

export function Transactions() {
  const [data, setData] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('kiaan_token')
        const res = await fetch('http://localhost:5000/api/v1/billing/transactions', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        const json = await res.json()
        if (json.success) {
          const formatted = json.data.map(tx => ({
            id: tx.transactionId,
            amount: tx.amount,
            status: tx.status
          }))
          setData(formatted)
        }
      } catch (error) {
        console.error("Failed to fetch transactions", error)
      }
    }
    fetchData()
  }, [])

  const columns = [{ key: "id", label: "Transaction ID", isPrimary: true }, { key: "amount", label: "Amount" }, { key: "status", label: "Status" }]
  return <MasterDataLayout title="Transactions" payment description="View all payment transactions." columns={columns} data={data} />
}


export function ScheduledReports() {
  const columns = [{ key: "name", label: "Report Name", isPrimary: true }, { key: "schedule", label: "Schedule" }]
  const data = [{ name: "Weekly Revenue", schedule: "Every Monday 9AM" }]
  return <MasterDataLayout title="Scheduled Reports" description="Automated report deliveries." columns={columns} data={data} />
}

export function ExportsCenter() {
  const columns = [{ key: "file", label: "File Name", isPrimary: true }, { key: "date", label: "Export Date" }, { key: "status", label: "Status" }]
  const data = [{ file: "users_export_2023.csv", date: "Today", status: "Completed" }]
  return <MasterDataLayout title="Exports Center" description="Download center for background exports." columns={columns} data={data} />
}



export function UIComponents() {
  const columns = [{ key: "component", label: "Component Name", isPrimary: true }, { key: "status", label: "Status" }]
  const data = [{ component: "Button", status: "Stable" }, { component: "Modal", status: "Beta" }]
  return <MasterDataLayout title="UI Components" description="Component library reference." columns={columns} data={data} />
}


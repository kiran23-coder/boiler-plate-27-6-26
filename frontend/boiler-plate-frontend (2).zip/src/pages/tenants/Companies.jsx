import { useState, useMemo, useEffect } from "react"
import { Building2, Search, Plus, MoreHorizontal, MapPin, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"

export function Companies() {
  const [list, setList] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  
  // Master data for dropdowns
  const [countries, setCountries] = useState([])
  const [states, setStates] = useState([])
  const [cities, setCities] = useState([])
  const [categories, setCategories] = useState([])

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)

  const { addToast } = useToast()

  // API Fetch Helper
  const apiFetch = async (url, method = 'GET', body = null) => {
    const token = localStorage.getItem('kiaan_token');
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);
    const response = await fetch(`http://localhost:5000/api/v1${url}`, config);
    return await response.json();
  };

  const fetchData = async () => {
    const [resTenants, resCountries, resStates, resCities, resCategories] = await Promise.all([
      apiFetch('/tenants'),
      apiFetch('/master/country'),
      apiFetch('/master/state'),
      apiFetch('/master/city'),
      apiFetch('/master/category')
    ]);

    if (resTenants.success) setList(resTenants.data);
    if (resCountries.success) setCountries(resCountries.data);
    if (resStates.success) setStates(resStates.data);
    if (resCities.success) setCities(resCities.data);
    if (resCategories.success) setCategories(resCategories.data);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const filteredList = useMemo(() => {
    if (!searchTerm) return list
    return list.filter(item => 
      Object.values(item).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  }, [list, searchTerm])

  const handleOpenAdd = () => {
    setFormData({ name: '', country: '', state: '', city: '', category: '', tags: '', industry: '', employees: '', status: 'ACTIVE' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch('/tenants', 'POST', formData);
    if (res.success) {
      setList([res.data, ...list])
      setIsAddModalOpen(false)
      addToast(`Company added successfully!`)
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch(`/tenants/${selectedItem.id}`, 'PUT', formData);
    if (res.success) {
      setList(list.map(item => item.id === selectedItem.id ? res.data : item))
      setIsEditModalOpen(false)
      addToast(`Company updated successfully!`)
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleDeleteSubmit = async () => {
    const res = await apiFetch(`/tenants/${selectedItem.id}`, 'DELETE');
    if (res.success) {
      setList(list.filter(item => item.id !== selectedItem.id))
      setIsDeleteModalOpen(false)
      addToast(`Company deleted successfully!`, 'info')
    } else {
      addToast(`Error: ${res.error}`, 'error')
    }
  }

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center">
            <Building2 className="mr-2 h-6 w-6 text-slate-400" /> Companies (Tenants)
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Manage your multi-tenant organizations and their core details.
          </p>
        </div>
        <Button onClick={handleOpenAdd}>
          <Plus className="mr-2 h-4 w-4" /> Add Company
        </Button>
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search companies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
        </div>

        {filteredList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-slate-100 p-3 dark:bg-slate-800 mb-4">
              <Search className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No companies found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Get started by creating a new company.
            </p>
            <Button className="mt-4" onClick={handleOpenAdd}>
              <Plus className="mr-2 h-4 w-4" /> Add Company
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full whitespace-nowrap text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Company Name</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Location</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Industry</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Employees</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Plan</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Tags</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Status</th>
                  <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
                {filteredList.map((company) => (
                  <tr key={company.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-white">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center text-primary font-bold">
                          {company.name.charAt(0)}
                        </div>
                        <span>{company.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400 flex items-center">
                      <MapPin className="mr-1 h-3 w-3 flex-shrink-0" /> {company.city}, {company.state}, {company.country}
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">{company.industry}</td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">{company.employees}</td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-primary/10 text-primary dark:bg-primary/20">
                        {company.plan}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {company.tags && (
                        <span className="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                          {company.tags}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        company.status === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
                        company.status === 'Pending' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' :
                        'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {company.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2">
                        <button 
                          onClick={() => handleOpenEdit(company)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-slate-800 dark:hover:text-primary transition-colors"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => handleOpenDelete(company)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-red-500 dark:hover:bg-slate-800 dark:hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Add New Company" : "Edit Company"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Company Name</label>
            <input type="text" required value={formData.name || ''} onChange={(e) => handleInputChange('name', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Country</label>
              <select value={formData.country || ''} onChange={(e) => handleInputChange('country', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select Country</option>
                {countries.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">State</label>
              <select value={formData.state || ''} onChange={(e) => handleInputChange('state', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select State</option>
                {states.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">City</label>
              <select value={formData.city || ''} onChange={(e) => handleInputChange('city', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select City</option>
                {cities.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Category</label>
              <select value={formData.category || ''} onChange={(e) => handleInputChange('category', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select Category</option>
                {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Tags</label>
              <input type="text" placeholder="#VIP, #Trial" value={formData.tags || ''} onChange={(e) => handleInputChange('tags', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Industry</label>
              <input type="text" required value={formData.industry || ''} onChange={(e) => handleInputChange('industry', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Employees</label>
              <input type="text" required value={formData.employees || ''} onChange={(e) => handleInputChange('employees', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Billing Plan</label>
              <select value={formData.plan || 'Starter'} onChange={(e) => handleInputChange('plan', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="Starter">Starter ($49/mo)</option>
                <option value="Professional">Professional ($99/mo)</option>
                <option value="Enterprise">Enterprise ($249/mo)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
              <select value={formData.status || 'Active'} onChange={(e) => handleInputChange('status', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="Active">Active</option>
                <option value="Pending">Pending</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Create Company' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete <strong>{selectedItem?.name}</strong>? This action cannot be undone.
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete Company
          </Button>
        </div>
      </Modal>
    </div>
  )
}

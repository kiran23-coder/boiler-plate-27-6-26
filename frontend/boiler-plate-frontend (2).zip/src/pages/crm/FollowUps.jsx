import { useState, useMemo } from "react"
import { Calendar, Search, Plus, MoreHorizontal, Phone, Mail, Clock, CheckCircle, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { useCRM } from "@/contexts/CRMContext"

export function FollowUps() {
  const { followUps, setFollowUps, addFollowUp, updateFollowUp, deleteFollowUp, leads } = useCRM()
  
  const [searchTerm, setSearchTerm] = useState("")
  
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)

  const { addToast } = useToast()

  const filteredList = useMemo(() => {
    if (!searchTerm) return followUps
    return followUps.filter(item => 
      Object.values(item).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  }, [followUps, searchTerm])

  const handleOpenAdd = () => {
    setFormData({ title: '', leadName: '', company: '', date: new Date().toISOString().split('T')[0], type: 'Call', status: 'Pending', owner: 'Alice Freeman' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item })
    setIsEditModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await addFollowUp(formData)
    if (res?.success) {
      setIsAddModalOpen(false)
      addToast(`Follow-up scheduled successfully!`)
    } else {
      addToast(`Failed to schedule follow-up`, 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await updateFollowUp({ ...formData, id: selectedItem.id })
    if (res?.success) {
      setIsEditModalOpen(false)
      addToast(`Follow-up updated successfully!`)
    } else {
      addToast(`Failed to update follow-up`, 'error')
    }
  }

  const markAsCompleted = async (item) => {
    const res = await updateFollowUp({ ...item, status: 'Completed' })
    if (res?.success) {
      addToast(`Follow-up marked as completed!`, 'success')
    } else {
      addToast(`Failed to update status`, 'error')
    }
  }

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this follow-up?")) {
      const res = await deleteFollowUp(id)
      if (res?.success) {
        addToast(`Follow-up deleted!`, 'info')
      } else {
        addToast(`Failed to delete`, 'error')
      }
    }
  }

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center">
            <Clock className="mr-2 h-6 w-6 text-slate-400" /> Follow Ups
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Never miss a beat. Schedule and track your calls, meetings, and emails with leads.
          </p>
        </div>
        <Button onClick={handleOpenAdd}>
          <Plus className="mr-2 h-4 w-4" /> Schedule Follow-up
        </Button>
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search follow-ups..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
        </div>

        {filteredList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-slate-100 p-3 dark:bg-slate-800 mb-4">
              <Calendar className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No follow-ups scheduled</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              You are all caught up!
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full whitespace-nowrap text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Title</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Lead / Company</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Date</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Type</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Status</th>
                  <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
                {filteredList.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-white">
                      {item.title}
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div>{item.leadName}</div>
                      <div className="text-xs text-slate-400">{item.company}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div className="flex items-center"><Calendar className="mr-1.5 h-3 w-3" /> {item.date}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400`}>
                        {item.type === 'Call' && <Phone className="mr-1 h-3 w-3" />}
                        {item.type === 'Email' && <Mail className="mr-1 h-3 w-3" />}
                        {item.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        item.status === 'Completed' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2 items-center">
                        {item.status !== 'Completed' && (
                          <button 
                            onClick={() => markAsCompleted(item.id)}
                            className="mr-2 inline-flex items-center text-xs font-medium text-green-600 hover:text-green-700 transition-colors"
                            title="Mark as Completed"
                          >
                            <CheckCircle className="mr-1 h-4 w-4" /> Done
                          </button>
                        )}
                        <button 
                          onClick={() => handleOpenEdit(item)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-slate-800 dark:hover:text-primary transition-colors"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(item.id)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-red-500 dark:hover:bg-slate-800 dark:hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Schedule Follow-up" : "Edit Follow-up"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Title / Purpose</label>
            <input type="text" required value={formData.title || ''} onChange={(e) => handleInputChange('title', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Lead Name</label>
              <input type="text" required value={formData.leadName || ''} onChange={(e) => handleInputChange('leadName', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Company</label>
              <input type="text" value={formData.company || ''} onChange={(e) => handleInputChange('company', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Date</label>
              <input type="date" required value={formData.date || ''} onChange={(e) => handleInputChange('date', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Type</label>
              <select value={formData.type || 'Call'} onChange={(e) => handleInputChange('type', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="Call">Call</option>
                <option value="Email">Email</option>
                <option value="Meeting">Meeting</option>
              </select>
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Schedule' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

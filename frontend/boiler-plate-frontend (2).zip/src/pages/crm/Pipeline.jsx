import { useState, useRef, useEffect } from "react"
import { Plus, MoreHorizontal, MessageSquare, Paperclip, Calendar, Edit2, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { useCRM } from "@/contexts/CRMContext"

export function Pipeline() {
  const { pipelineStages: stages, addDealToPipeline, updateLead, deleteLead, leads } = useCRM()
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditMode, setIsEditMode] = useState(false)
  const [editDealId, setEditDealId] = useState(null)
  const [formData, setFormData] = useState({ title: '', company: '', amount: '', stageId: 'NEW' })
  const [activeDropdown, setActiveDropdown] = useState(null)
  const dropdownRef = useRef(null)
  const { addToast } = useToast()

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setActiveDropdown(null)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleOpenAdd = (stageId = 'NEW') => {
    setIsEditMode(false)
    setFormData({ title: '', company: '', amount: '', stageId })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (card, stageId) => {
    setIsEditMode(true)
    setEditDealId(card.id)
    setFormData({ 
      title: card.title, 
      company: card.company, 
      amount: card.amount.replace('$', ''), 
      stageId 
    })
    setActiveDropdown(null)
    setIsAddModalOpen(true)
  }

  const handleDelete = async (cardId) => {
    if (window.confirm("Are you sure you want to delete this deal?")) {
      await deleteLead(cardId)
      addToast('Deal deleted successfully!')
      setActiveDropdown(null)
    }
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    
    if (isEditMode) {
      const originalLead = leads.find(l => l.id === editDealId)
      if (originalLead) {
        await updateLead({
          ...originalLead,
          name: formData.title,
          companyName: formData.company,
          dealAmount: formData.amount,
          status: formData.stageId
        })
        addToast('Deal updated successfully!')
      }
    } else {
      await addDealToPipeline({
        title: formData.title,
        company: formData.company,
        amount: formData.amount
      }, formData.stageId)
      addToast('Deal created successfully!')
    }

    setIsAddModalOpen(false)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-12rem)]">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Pipeline Board</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Track your sales pipeline across different stages.
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">Pipeline Settings</Button>
          <Button onClick={() => handleOpenAdd()}>
            <Plus className="mr-2 h-4 w-4" /> Add Deal
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto pb-4">
        <div className="flex h-full space-x-6 min-w-max">
          {stages.map((stage) => (
            <div key={stage.id} className="flex flex-col w-80 max-h-full rounded-xl bg-slate-100/50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800">
              <div className={`flex items-center justify-between p-4 border-t-4 rounded-t-xl ${stage.color}`}>
                <h3 className="font-semibold text-slate-900 dark:text-white flex items-center">
                  {stage.title}
                  <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-slate-200 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                    {stage.cards.length}
                  </span>
                </h3>
                <button className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
                  <MoreHorizontal className="h-5 w-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-3">
                {stage.cards.map((card) => (
                  <div key={card.id} className="group cursor-pointer rounded-lg border border-slate-200 bg-white p-4 shadow-sm hover:border-primary/50 hover:shadow-md dark:border-slate-700 dark:bg-slate-950 dark:hover:border-primary/50 transition-all relative">
                    <div className="flex justify-between items-start mb-2">
                      <span className="inline-flex items-center rounded bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                        {card.company}
                      </span>
                      <div className="relative">
                        <button 
                          onClick={(e) => { e.stopPropagation(); setActiveDropdown(activeDropdown === card.id ? null : card.id); }}
                          className={`text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-opacity ${activeDropdown === card.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                        {activeDropdown === card.id && (
                          <div ref={dropdownRef} className="absolute right-0 top-6 w-32 rounded-md bg-white shadow-lg border border-slate-200 dark:bg-slate-800 dark:border-slate-700 z-10 py-1">
                            <button onClick={(e) => { e.stopPropagation(); handleOpenEdit(card, stage.id); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700 flex items-center">
                              <Edit2 className="mr-2 h-4 w-4" /> Edit
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); handleDelete(card.id); }} className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20 flex items-center">
                              <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    <h4 className="font-medium text-slate-900 dark:text-white text-sm mb-1">{card.title}</h4>
                    <p className="text-lg font-bold text-slate-900 dark:text-white mb-4">{card.amount}</p>
                    
                    <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                      <div className="flex items-center space-x-3">
                        {card.tasks > 0 && (
                          <div className="flex items-center">
                            <MessageSquare className="mr-1 h-3 w-3" /> {card.tasks}
                          </div>
                        )}
                        {card.files > 0 && (
                          <div className="flex items-center">
                            <Paperclip className="mr-1 h-3 w-3" /> {card.files}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-3 w-3" /> {card.date}
                      </div>
                    </div>
                  </div>
                ))}
                
                <button 
                  onClick={() => handleOpenAdd(stage.id)}
                  className="flex w-full items-center justify-center rounded-lg border-2 border-dashed border-slate-200 py-3 text-sm font-medium text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-slate-800 dark:hover:border-slate-700 dark:hover:text-slate-300 transition-colors"
                >
                  <Plus className="mr-1 h-4 w-4" /> Add Deal
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title={isEditMode ? "Edit Deal" : "Create New Deal"}>
        <form onSubmit={handleAddSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Deal Title</label>
            <input type="text" required value={formData.title} onChange={(e) => setFormData(p => ({ ...p, title: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Company</label>
            <input type="text" required value={formData.company} onChange={(e) => setFormData(p => ({ ...p, company: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Amount</label>
              <input type="text" required value={formData.amount} onChange={(e) => setFormData(p => ({ ...p, amount: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Stage</label>
              <select value={formData.stageId} onChange={(e) => setFormData(p => ({ ...p, stageId: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                {stages.map(stage => (
                  <option key={stage.id} value={stage.id}>{stage.title}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => setIsAddModalOpen(false)}>Cancel</Button>
            <Button type="submit">{isEditMode ? "Save Changes" : "Create Deal"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

import { useState, useEffect } from "react"
import { Search, Filter, Download, FileText, CheckCircle2, Clock } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown"

export function Invoices() {
  const [invoices, setInvoices] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("All")

  const fetchInvoices = async () => {
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch('http://localhost:5000/api/v1/billing/invoices', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      const data = await res.json()
      if (data.success) {
        setInvoices(data.data)
      }
    } catch (error) {
      console.error("Failed to fetch invoices:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchInvoices()
  }, [])

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.invoiceId?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          invoice.plan?.name?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = statusFilter === "All" || invoice.status === statusFilter
    return matchesSearch && matchesFilter
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Invoices & Billing History</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            View and download your previous invoices.
          </p>
        </div>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" /> Download All
        </Button>
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search invoices..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
          <Dropdown
            align="right"
            trigger={
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" /> 
                {statusFilter === "All" ? "Filter" : statusFilter}
              </Button>
            }
          >
            <DropdownItem onClick={() => setStatusFilter("All")}>All Invoices</DropdownItem>
            <DropdownItem onClick={() => setStatusFilter("Paid")}>Paid</DropdownItem>
            <DropdownItem onClick={() => setStatusFilter("Pending")}>Pending</DropdownItem>
          </Dropdown>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap text-left text-sm">
            <thead className="bg-slate-50 dark:bg-slate-900/50">
              <tr>
                <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Invoice ID</th>
                <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Date</th>
                <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Plan</th>
                <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Amount</th>
                <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Status</th>
                <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
              {isLoading ? (
                 <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-slate-500 dark:text-slate-400">
                    Loading invoices...
                  </td>
                </tr>
              ) : filteredInvoices.length > 0 ? (
                filteredInvoices.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-white flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-slate-400" />
                      <span>{invoice.invoiceId}</span>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">{invoice.date}</td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">{invoice.plan?.name || 'Custom'}</td>
                    <td className="px-6 py-4 text-slate-900 font-medium dark:text-white">{invoice.amount}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        invoice.status === 'Paid' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
                        'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400'
                      }`}>
                        {invoice.status === 'Paid' ? <CheckCircle2 className="mr-1 h-3 w-3" /> : <Clock className="mr-1 h-3 w-3" />}
                        {invoice.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-3 w-3" /> PDF
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-slate-500 dark:text-slate-400">
                    No invoices found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

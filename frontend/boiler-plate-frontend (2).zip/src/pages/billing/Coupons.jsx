import { useState, useEffect } from "react"
import { Tag, Plus, MoreHorizontal, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { Dropdown, DropdownItem } from "@/components/ui/Dropdown"

export function Coupons() {
  const [list, setList] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [isActionLoading, setIsActionLoading] = useState(false)
  
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)
  
  const { addToast } = useToast()

  const fetchCoupons = async () => {
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch('http://localhost:5000/api/v1/billing/coupons', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      const data = await res.json()
      if (data.success) {
        setList(data.data)
      }
    } catch (error) {
      console.error("Failed to fetch coupons:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchCoupons()
  }, [])

  const handleOpenAdd = () => {
    setFormData({ code: '', discount: '', status: 'Active', expires: '' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    setIsActionLoading(true)
    const payload = { 
      ...formData, 
      uses: "0/100", 
      type: formData.discount?.includes('%') ? 'Percentage' : 'Fixed Amount' 
    }
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch('http://localhost:5000/api/v1/billing/coupons', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })
      const data = await res.json()
      if (data.success) {
        addToast(`Coupon created successfully!`)
        fetchCoupons()
        setIsAddModalOpen(false)
      } else {
        addToast(data.error?.message || 'Failed to create coupon', 'error')
      }
    } catch (error) {
      addToast('Network error', 'error')
    } finally {
      setIsActionLoading(false)
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    setIsActionLoading(true)
    const payload = { 
      ...formData, 
      type: formData.discount?.includes('%') ? 'Percentage' : 'Fixed Amount' 
    }
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch(`http://localhost:5000/api/v1/billing/coupons/${selectedItem.id}`, {
        method: 'PUT',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })
      const data = await res.json()
      if (data.success) {
        addToast(`Coupon updated successfully!`)
        fetchCoupons()
        setIsEditModalOpen(false)
      } else {
        addToast(data.error?.message || 'Failed to update coupon', 'error')
      }
    } catch (error) {
      addToast('Network error', 'error')
    } finally {
      setIsActionLoading(false)
    }
  }

  const handleDeleteSubmit = async () => {
    setIsActionLoading(true)
    try {
      const token = localStorage.getItem('kiaan_token')
      const res = await fetch(`http://localhost:5000/api/v1/billing/coupons/${selectedItem.id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      })
      const data = await res.json()
      if (data.success) {
        addToast(`Coupon deleted successfully!`)
        fetchCoupons()
        setIsDeleteModalOpen(false)
      } else {
        addToast(data.error?.message || 'Failed to delete coupon', 'error')
      }
    } catch (error) {
      addToast('Network error', 'error')
    } finally {
      setIsActionLoading(false)
    }
  }

  if (isLoading) {
    return <div className="p-8 text-center text-slate-500">Loading coupons...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Coupons & Promotions</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Create and manage discount codes for your customers.
          </p>
        </div>
        <Button onClick={handleOpenAdd}>
          <Plus className="mr-2 h-4 w-4" /> Create Coupon
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {list.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-500 border rounded-xl border-dashed">
            No coupons created yet.
          </div>
        ) : (
          list.map((coupon) => (
            <div key={coupon.id} className="flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
              <div className="flex items-center justify-between border-b border-slate-100 p-5 dark:border-slate-800/50">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Tag className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-mono text-sm font-bold text-slate-900 dark:text-white">{coupon.code}</h3>
                    <div className="mt-1 flex items-center space-x-2">
                      <div className={`h-2 w-2 rounded-full ${
                        coupon.status === 'Active' ? 'bg-green-500' : 
                        coupon.status === 'Scheduled' ? 'bg-blue-500' : 'bg-slate-400'
                      }`} />
                      <span className="text-xs font-medium text-slate-500">{coupon.status}</span>
                    </div>
                  </div>
                </div>
                <Dropdown
                  trigger={
                    <button className="text-slate-400 hover:text-slate-500 dark:hover:text-slate-300">
                      <MoreHorizontal className="h-5 w-5" />
                    </button>
                  }
                >
                  <DropdownItem icon={Edit} onClick={() => handleOpenEdit(coupon)}>Edit Coupon</DropdownItem>
                  <DropdownItem icon={Trash2} onClick={() => handleOpenDelete(coupon)}>Delete</DropdownItem>
                </Dropdown>
              </div>
              <div className="flex-1 p-5 space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Discount</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{coupon.discount}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Uses</span>
                  <span className="font-medium text-slate-700 dark:text-slate-300">{coupon.uses}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Expires</span>
                  <span className="text-slate-700 dark:text-slate-300">{coupon.expires}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Create New Coupon" : "Edit Coupon"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Coupon Code</label>
            <input type="text" required value={formData.code || ''} onChange={(e) => setFormData(p => ({ ...p, code: e.target.value.toUpperCase() }))} placeholder="e.g. SUMMER50" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white uppercase" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Discount Amount</label>
            <input type="text" required pattern="^\$?[0-9]+(\.[0-9]{1,2})?%?$" title="Enter a valid amount (e.g., 50% or $20)" value={formData.discount || ''} onChange={(e) => setFormData(p => ({ ...p, discount: e.target.value }))} placeholder="e.g. 50% or $20" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
              <select value={formData.status || 'Active'} onChange={(e) => setFormData(p => ({ ...p, status: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="Active">Active</option>
                <option value="Scheduled">Scheduled</option>
                <option value="Expired">Expired</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Expiration Date</label>
              <input type="date" required value={formData.expires || ''} onChange={(e) => setFormData(p => ({ ...p, expires: e.target.value }))} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" disabled={isActionLoading} onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit" disabled={isActionLoading}>{isActionLoading ? 'Saving...' : (isAddModalOpen ? 'Create Coupon' : 'Save Changes')}</Button>
          </div>
        </form>
      </Modal>

      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete the coupon <strong>{selectedItem?.code}</strong>?
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" disabled={isActionLoading} onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" disabled={isActionLoading} className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            {isActionLoading ? 'Deleting...' : 'Delete Coupon'}
          </Button>
        </div>
      </Modal>
    </div>
  )
}

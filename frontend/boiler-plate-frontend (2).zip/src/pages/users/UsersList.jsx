import { useState, useMemo, useEffect } from "react"
import { Search, Plus, MoreHorizontal, Mail, Shield, Filter, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"

export function UsersList() {
  const [list, setList] = useState([])
  const [departments, setDepartments] = useState([])
  const [teams, setTeams] = useState([])
  const [roles, setRoles] = useState([])
  
  const [searchTerm, setSearchTerm] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({ role: 'All', status: 'All' })
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)

  const { addToast } = useToast()

  const apiFetch = async (url, method = 'GET', body = null) => {
    const token = localStorage.getItem('kiaan_token');
    if (!token) return { success: false };
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    const config = { method, headers };
    if (body) config.body = JSON.stringify(body);
    const response = await fetch(`http://localhost:5000/api/v1${url}`, config);
    return await response.json();
  };

  const fetchUsers = async () => {
    const res = await apiFetch('/users');
    if (res.success) setList(res.data);
  };

  const fetchLookups = async () => {
    const [rolesRes, deptsRes, teamsRes] = await Promise.all([
      apiFetch('/roles'),
      apiFetch('/master/department'),
      apiFetch('/master/team')
    ]);
    if (rolesRes.success) setRoles(rolesRes.data);
    if (deptsRes.success) setDepartments(deptsRes.data);
    if (teamsRes.success) setTeams(teamsRes.data);
  };

  useEffect(() => {
    fetchUsers();
    fetchLookups();
  }, []);

  const filteredList = useMemo(() => {
    let result = list

    if (searchTerm) {
      result = result.filter(item => 
        Object.values(item).some(val => 
          String(val).toLowerCase().includes(searchTerm.toLowerCase())
        )
      )
    }

    if (filters.role !== 'All') {
      result = result.filter(item => item.role === filters.role)
    }
    if (filters.status !== 'All') {
      result = result.filter(item => item.status === filters.status)
    }

    return result
  }, [list, searchTerm, filters])

  const handleOpenAdd = () => {
    setFormData({ name: '', email: '', password: '', role: 'Staff', department: '', team: '', status: 'Active' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ name: item.name, email: item.email, role: item.role, department: item.department, team: item.team, status: item.status })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch('/users', 'POST', formData);
    if (res.success) {
      setList([res.data, ...list])
      setIsAddModalOpen(false)
      addToast(`User added successfully!`)
    } else {
      addToast(res.error || 'Failed to add user', 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await apiFetch(`/users/${selectedItem.id}`, 'PUT', formData);
    if (res.success) {
      setList(list.map(item => item.id === selectedItem.id ? res.data : item))
      setIsEditModalOpen(false)
      addToast(`User updated successfully!`)
    } else {
      addToast(res.error || 'Failed to update user', 'error')
    }
  }

  const handleDeleteSubmit = async () => {
    const res = await apiFetch(`/users/${selectedItem.id}`, 'DELETE');
    if (res.success) {
      setList(list.filter(item => item.id !== selectedItem.id))
      setIsDeleteModalOpen(false)
      addToast(`User deleted successfully!`, 'info')
    } else {
      addToast(res.error || 'Failed to delete user', 'error')
    }
  }

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  // Filter teams based on selected department for dropdown
  const availableTeams = teams.filter(t => t.department === formData.department);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">User Management</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Manage your employees, their roles, and system access.
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className={showFilters ? 'bg-slate-100 dark:bg-slate-800' : ''}>
            <Filter className="mr-2 h-4 w-4" /> Filters
          </Button>
          <Button onClick={handleOpenAdd}>
            <Plus className="mr-2 h-4 w-4" /> Add User
          </Button>
        </div>
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
        </div>

        {showFilters && (
          <div className="border-b border-slate-200 px-6 py-4 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/50">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1 dark:text-slate-400">Role</label>
                <select 
                  value={filters.role} 
                  onChange={(e) => setFilters(p => ({...p, role: e.target.value}))}
                  className="w-full h-9 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300"
                >
                  <option value="All">All Roles</option>
                  {roles.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1 dark:text-slate-400">Status</label>
                <select 
                  value={filters.status} 
                  onChange={(e) => setFilters(p => ({...p, status: e.target.value}))}
                  className="w-full h-9 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300"
                >
                  <option value="All">All Statuses</option>
                  <option value="Active">Active</option>
                  <option value="Pending">Pending</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setFilters({ role: 'All', status: 'All' })}
                className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              >
                Clear all filters
              </Button>
            </div>
          </div>
        )}

        {filteredList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-slate-100 p-3 dark:bg-slate-800 mb-4">
              <Search className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No users found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Get started by creating a new user.
            </p>
            <Button className="mt-4" onClick={handleOpenAdd}>
              <Plus className="mr-2 h-4 w-4" /> Add User
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full whitespace-nowrap text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">User</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Contact</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Role</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Department</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Status</th>
                  <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
                {filteredList.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-white">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 font-bold text-xs">
                          {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                        <span>{user.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div className="flex items-center">
                        <Mail className="mr-2 h-3 w-3" /> {user.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div className="flex items-center">
                        <Shield className="mr-2 h-3 w-3" /> {user.role}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div className="font-medium text-slate-700 dark:text-slate-300">{user.department}</div>
                      <div className="text-xs">{user.team}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        user.status === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' :
                        user.status === 'Pending' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' :
                        'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {user.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2">
                        <button 
                          onClick={() => handleOpenEdit(user)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-slate-800 dark:hover:text-primary transition-colors"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => handleOpenDelete(user)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-red-500 dark:hover:bg-slate-800 dark:hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Add New User" : "Edit User"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
            <input type="text" required value={formData.name || ''} onChange={(e) => handleInputChange('name', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
              <input type="email" required value={formData.email || ''} onChange={(e) => handleInputChange('email', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Password</label>
              <input type="password" required={isAddModalOpen} value={formData.password || ''} onChange={(e) => handleInputChange('password', e.target.value)} placeholder={isEditModalOpen ? "Leave blank to keep same" : "••••••••"} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Role</label>
              <select value={formData.role || ''} onChange={(e) => handleInputChange('role', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select Role</option>
                {roles.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Department</label>
              <select 
                value={formData.department || ''} 
                onChange={(e) => {
                  const newDept = e.target.value;
                  setFormData(prev => ({ ...prev, department: newDept, team: '' }));
                }} 
                className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              >
                <option value="">Select Department</option>
                {departments.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Team</label>
              <select value={formData.team || ''} onChange={(e) => handleInputChange('team', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">Select Team</option>
                {availableTeams.map(t => <option key={t.id} value={t.name}>{t.name}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
            <select value={formData.status || 'Active'} onChange={(e) => handleInputChange('status', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
              <option value="Active">Active</option>
              <option value="Pending">Pending</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Create User' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete <strong>{selectedItem?.name}</strong>? This action cannot be undone.
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete User
          </Button>
        </div>
      </Modal>
    </div>
  )
}

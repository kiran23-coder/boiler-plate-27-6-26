import { MasterDataLayout } from "./MasterData"

export function States() {
  const columns = [
    { key: "code", label: "State Code", isPrimary: true },
    { key: "name", label: "State Name" },
    { key: "country", label: "Country" },
    { 
      key: "status", 
      label: "Status",
      render: (val) => (
        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
          val === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400'
        }`}>
          {val}
        </span>
      )
    }
  ]
  return <MasterDataLayout title="States" description="Manage states and regions." columns={columns} entity="state" />
}

export function Cities() {
  const columns = [
    { key: "name", label: "City Name", isPrimary: true },
    { key: "state", label: "State" },
    { key: "country", label: "Country" },
  ]
  return <MasterDataLayout title="Cities" description="Manage cities for location data." columns={columns} entity="city" />
}

export function Categories() {
  const columns = [
    { key: "name", label: "Category Name", isPrimary: true },
    { key: "type", label: "Type" },
    { key: "items", label: "Items Count", hideInForm: true },
  ]
  return <MasterDataLayout title="Categories" description="Manage global categories." columns={columns} entity="category" />
}

export function Tags() {
  const columns = [
    { key: "name", label: "Tag Name", isPrimary: true },
    { key: "color", label: "Color", render: (val) => <div className="flex items-center"><div className="w-4 h-4 rounded-full mr-2" style={{backgroundColor: val}}></div>{val}</div> },
  ]
  return <MasterDataLayout title="Tags" description="Manage system-wide tags." columns={columns} entity="tag" />
}

export function Units() {
  const columns = [
    { key: "name", label: "Unit Name", isPrimary: true },
    { key: "symbol", label: "Symbol" },
  ]
  return <MasterDataLayout title="Units" description="Manage measurement units." columns={columns} entity="unit" />
}

export function Taxes() {
  const columns = [
    { key: "name", label: "Tax Name", isPrimary: true },
    { key: "rate", label: "Rate (%)" },
  ]
  return <MasterDataLayout title="Taxes" description="Manage tax rates." columns={columns} entity="tax" />
}

export function Statuses() {
  const columns = [
    { key: "name", label: "Status Name", isPrimary: true },
    { key: "module", label: "Module" },
  ]
  return <MasterDataLayout title="Statuses" description="Manage custom statuses." columns={columns} entity="status" />
}

import { useState, useMemo } from "react"
import { Users, Search, Plus, MoreHorizontal, Mail, Phone, ExternalLink, ArrowRight, Edit, Trash2, Send, Bot, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/Button"
import { Modal } from "@/components/ui/Modal"
import { useToast } from "@/components/ui/ToastContext"
import { useCRM } from "@/contexts/CRMContext"
import { useSystem } from "@/contexts/SystemContext"

export function Leads() {
  const { leads, addLead, updateLead, deleteLead, convertToDeal } = useCRM()
  const { emailTemplates, addAuditLog, logAIUsage } = useSystem()
  
  const [searchTerm, setSearchTerm] = useState("")
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false)
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false)
  
  const [formData, setFormData] = useState({})
  const [selectedItem, setSelectedItem] = useState(null)
  const [dealAmount, setDealAmount] = useState("")
  const [emailData, setEmailData] = useState({ templateId: '', body: '', isAIGenerating: false })

  const { addToast } = useToast()

  const filteredList = useMemo(() => {
    if (!searchTerm) return leads
    return leads.filter(item => 
      Object.values(item).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    )
  }, [leads, searchTerm])

  const handleOpenAdd = () => {
    setFormData({ name: '', company: '', email: '', phone: '', status: 'NEW', owner: '', source: 'Website', dealAmount: '' })
    setIsAddModalOpen(true)
  }

  const handleOpenEdit = (item) => {
    setSelectedItem(item)
    setFormData({ ...item, company: item.companyName || item.company })
    setIsEditModalOpen(true)
  }

  const handleOpenDelete = (item) => {
    setSelectedItem(item)
    setIsDeleteModalOpen(true)
  }

  const handleOpenConvert = (item) => {
    setSelectedItem(item)
    setDealAmount(item.dealAmount || "")
    setIsConvertModalOpen(true)
  }

  const handleOpenEmail = (item) => {
    setSelectedItem(item)
    setEmailData({ templateId: '', body: '', isAIGenerating: false })
    setIsEmailModalOpen(true)
  }

  const handleTemplateSelect = (e) => {
    const templateId = Number(e.target.value);
    const template = emailTemplates.find(t => t.id === templateId);
    if (template) {
      // Basic merge tag replacement
      const body = template.body
        .replace('{{name}}', selectedItem.name.split(' ')[0])
        .replace('{{company}}', selectedItem.companyName || selectedItem.company || '');
      setEmailData(prev => ({ ...prev, templateId, body }));
    } else {
      setEmailData(prev => ({ ...prev, templateId: '', body: '' }));
    }
  }

  const handleAIGenerate = () => {
    setEmailData(prev => ({ ...prev, isAIGenerating: true }));
    // Simulate AI generation
    setTimeout(() => {
      const generatedText = `Hi ${selectedItem.name.split(' ')[0]},\n\nI noticed you work at ${selectedItem.companyName || selectedItem.company || 'your company'}. I thought I'd reach out to see if you have any needs regarding our enterprise software solutions.\n\nLooking forward to hearing from you.\n\nBest,\nSales`;
      setEmailData(prev => ({ ...prev, body: generatedText, isAIGenerating: false }));
      logAIUsage("OpenAI GPT-4", "Generate outreach email for lead", 125);
      addToast("Email drafted by AI!", "success");
    }, 1500);
  }

  const handleSendEmail = (e) => {
    e.preventDefault();
    addAuditLog("COMMUNICATION", `Sent email to Lead: ${selectedItem.email}`);
    setIsEmailModalOpen(false);
    addToast("Email sent successfully!");
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    const res = await addLead(formData)
    if (res?.success) {
      setIsAddModalOpen(false)
      addToast(`Lead created successfully!`)
    } else {
      addToast(`Failed to create lead`, 'error')
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    const res = await updateLead({ ...formData, id: selectedItem.id })
    if (res?.success) {
      setIsEditModalOpen(false)
      addToast(`Lead updated successfully!`)
    } else {
      addToast(`Failed to update lead`, 'error')
    }
  }

  const handleDeleteSubmit = async () => {
    const res = await deleteLead(selectedItem.id)
    if (res?.success) {
      setIsDeleteModalOpen(false)
      addToast(`Lead deleted successfully!`, 'info')
    } else {
      addToast(`Failed to delete lead`, 'error')
    }
  }

  const handleConvertSubmit = (e) => {
    e.preventDefault()
    convertToDeal(selectedItem.id, dealAmount)
    setIsConvertModalOpen(false)
    addToast(`Lead converted to Deal and moved to Pipeline!`, 'success')
  }

  const handleInputChange = (key, value) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center">
            <Users className="mr-2 h-6 w-6 text-slate-400" /> Leads
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Manage your potential customers before they enter the sales pipeline.
          </p>
        </div>
        <Button onClick={handleOpenAdd}>
          <Plus className="mr-2 h-4 w-4" /> Add Lead
        </Button>
      </div>

      <div className="w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
        <div className="flex flex-col sm:flex-row items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800 space-y-4 sm:space-y-0">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search leads..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-10 w-full rounded-md border border-slate-300 bg-white pl-10 pr-4 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />
          </div>
        </div>

        {filteredList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-slate-100 p-3 dark:bg-slate-800 mb-4">
              <Search className="h-6 w-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 dark:text-white">No leads found</h3>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Get started by creating a new lead.
            </p>
            <Button className="mt-4" onClick={handleOpenAdd}>
              <Plus className="mr-2 h-4 w-4" /> Add Lead
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full whitespace-nowrap text-left text-sm">
              <thead className="bg-slate-50 dark:bg-slate-900/50">
                <tr>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Name</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Company</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Contact</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Status</th>
                  <th className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-200">Owner</th>
                  <th className="px-6 py-4 text-right font-semibold text-slate-900 dark:text-slate-200">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-transparent">
                {filteredList.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-6 py-4 font-medium text-slate-900 dark:text-white">
                      <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 font-bold text-xs">
                          {lead.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <span>{lead.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      {lead.companyName || lead.company || '-'}
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      <div className="flex flex-col space-y-1 text-xs">
                        <div className="flex items-center"><Mail className="mr-1.5 h-3 w-3" /> {lead.email}</div>
                        <div className="flex items-center"><Phone className="mr-1.5 h-3 w-3" /> {lead.phone}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        lead.status === 'NEW' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' :
                        lead.status === 'CONTACTED' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' :
                        lead.status === 'QUALIFIED' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400' :
                        'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {lead.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      {lead.owner || '-'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end space-x-2 items-center">
                        <button 
                          onClick={() => handleOpenEmail(lead)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-blue-500 dark:hover:bg-slate-800 dark:hover:text-blue-500 transition-colors"
                          title="Send Email"
                        >
                          <Send className="h-4 w-4" />
                        </button>
                        {lead.status !== 'Qualified' && (
                          <button 
                            onClick={() => handleOpenConvert(lead)}
                            className="mr-2 inline-flex items-center text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                            title="Convert to Deal"
                          >
                            Convert <ArrowRight className="ml-1 h-3 w-3" />
                          </button>
                        )}
                        <button 
                          onClick={() => handleOpenEdit(lead)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-slate-800 dark:hover:text-primary transition-colors"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => handleOpenDelete(lead)}
                          className="p-1 rounded-md text-slate-400 hover:bg-slate-100 hover:text-red-500 dark:hover:bg-slate-800 dark:hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal isOpen={isAddModalOpen || isEditModalOpen} onClose={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} title={isAddModalOpen ? "Add New Lead" : "Edit Lead"}>
        <form onSubmit={isAddModalOpen ? handleAddSubmit : handleEditSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Lead Name</label>
              <input type="text" required value={formData.name || ''} onChange={(e) => handleInputChange('name', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Company</label>
              <input type="text" required value={formData.company || ''} onChange={(e) => handleInputChange('company', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Email</label>
              <input type="email" required value={formData.email || ''} onChange={(e) => handleInputChange('email', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Phone</label>
              <input type="text" value={formData.phone || ''} onChange={(e) => handleInputChange('phone', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Status</label>
              <select value={formData.status || 'NEW'} onChange={(e) => handleInputChange('status', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="NEW">New</option>
                <option value="CONTACTED">Contacted</option>
                <option value="QUALIFIED">Qualified</option>
                <option value="LOST">Lost</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Lead Source</label>
              <select value={formData.source || 'Website'} onChange={(e) => handleInputChange('source', e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="Website">Website</option>
                <option value="Referral">Referral</option>
                <option value="Cold Call">Cold Call</option>
                <option value="Event">Event</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Owner</label>
              <input type="text" value={formData.owner || ''} onChange={(e) => handleInputChange('owner', e.target.value)} placeholder="e.g. Alice Freeman" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Expected Deal Amount</label>
              <input type="number" step="0.01" value={formData.dealAmount || ''} onChange={(e) => handleInputChange('dealAmount', e.target.value)} placeholder="e.g. 5000.00" className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }}>Cancel</Button>
            <Button type="submit">{isAddModalOpen ? 'Create Lead' : 'Save Changes'}</Button>
          </div>
        </form>
      </Modal>

      {/* Convert to Deal Modal */}
      <Modal isOpen={isConvertModalOpen} onClose={() => setIsConvertModalOpen(false)} title="Convert to Deal">
        <form onSubmit={handleConvertSubmit} className="space-y-4">
          <div className="py-2">
            <p className="text-slate-600 dark:text-slate-300 text-sm mb-4">
              You are about to convert <strong>{selectedItem?.name} ({selectedItem?.company})</strong> into a Deal. It will be moved to the Pipeline Board.
            </p>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Estimated Deal Amount</label>
              <input type="text" placeholder="$0" required value={dealAmount} onChange={(e) => setDealAmount(e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" />
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
            <Button variant="outline" type="button" onClick={() => setIsConvertModalOpen(false)}>Cancel</Button>
            <Button type="submit">Convert & Move to Pipeline</Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} title="Confirm Deletion">
        <div className="py-2">
          <p className="text-slate-600 dark:text-slate-300">
            Are you sure you want to delete <strong>{selectedItem?.name}</strong>? This action cannot be undone.
          </p>
        </div>
        <div className="mt-6 flex justify-end space-x-3 border-t border-slate-100 dark:border-slate-800 pt-4">
          <Button variant="outline" type="button" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
          <Button type="button" className="bg-red-600 hover:bg-red-700 text-white" onClick={handleDeleteSubmit}>
            Delete Lead
          </Button>
        </div>
      </Modal>
      {/* Send Email Modal */}
      <Modal isOpen={isEmailModalOpen} onClose={() => setIsEmailModalOpen(false)} title={`Email ${selectedItem?.name}`}>
        <form onSubmit={handleSendEmail} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">To</label>
            <input type="email" disabled value={selectedItem?.email || ''} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-slate-50 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400 cursor-not-allowed" />
          </div>
          <div className="flex justify-between items-end gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Use Template</label>
              <select value={emailData.templateId} onChange={handleTemplateSelect} className="w-full h-10 px-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white">
                <option value="">-- Select Template --</option>
                {emailTemplates.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>
            <div className="pb-1">
              <span className="text-sm text-slate-500 mx-2">OR</span>
            </div>
            <div>
              <Button type="button" variant="outline" className="border-purple-200 text-purple-700 hover:bg-purple-50 hover:text-purple-800 dark:border-purple-800 dark:text-purple-400 dark:hover:bg-purple-900/50" onClick={handleAIGenerate} disabled={emailData.isAIGenerating}>
                {emailData.isAIGenerating ? (
                  <span className="animate-pulse flex items-center"><Bot className="mr-2 h-4 w-4" /> Generating...</span>
                ) : (
                  <span className="flex items-center"><Sparkles className="mr-2 h-4 w-4" /> Write with AI</span>
                )}
              </Button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Message</label>
            <textarea 
              required 
              rows={6}
              value={emailData.body} 
              onChange={(e) => setEmailData(prev => ({ ...prev, body: e.target.value }))}
              placeholder="Write your email here..."
              className="w-full p-3 rounded-md border border-slate-300 bg-white text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white resize-none"
            />
          </div>
          <div className="mt-6 flex justify-between border-t border-slate-100 dark:border-slate-800 pt-4">
            <span className="text-xs text-slate-500 pt-2 flex items-center">
              <Sparkles className="mr-1 h-3 w-3 text-purple-500" /> AI Usage consumes tokens
            </span>
            <div className="flex space-x-3">
              <Button variant="outline" type="button" onClick={() => setIsEmailModalOpen(false)}>Cancel</Button>
              <Button type="submit"><Send className="mr-2 h-4 w-4" /> Send Email</Button>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  )
}
